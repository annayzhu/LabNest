qPCR Analysis Studio 离线版

1. 请先完整解压 ZIP，不要直接在压缩包预览中运行。
2. 双击 index.html，推荐最新版 Chrome、Edge 或 Safari。
3. 无需安装 Node.js，也不需要联网；实验文件仅在当前浏览器本地处理。
4. 本工具仅供科研使用。计算结果应结合原始数据、板布局、实验设计与 QC 复核。

Build date: 20261103